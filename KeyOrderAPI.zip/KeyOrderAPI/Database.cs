﻿// Please update your .tt file's `Settings.ConnectionString` string to the database you want to reverse engineer and save your .tt file.
